package edu.ycp.cs320.booksdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Scanner;

import edu.ycp.cs320.sqldemo.DBUtil;

public class InsertBookWithNewAuthor 
{
	public static void main(String[] args) throws Exception {
		// load Derby JDBC driver
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		} catch (Exception e) {
			System.err.println("Could not load Derby JDBC driver");
			System.err.println(e.getMessage());
			System.exit(1);
		}

		Connection conn = null;
		PreparedStatement stmt = null;
		PreparedStatement stmt2 = null;
		ResultSet resultSet = null;
		ResultSet resultSet2 = null;

		// connect to the database
		conn = DriverManager.getConnection("jdbc:derby:test.db;create=true");

		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);

		try {
			conn.setAutoCommit(true);
			
			// prompt user for title to search for
			System.out.print("Author's First Name to add: ");
			String authorFirstName = keyboard.nextLine();
			
			System.out.print("Author's Last Name to add: ");
			String authorLastName = keyboard.nextLine();
			
			System.out.print("Title to add: ");
			String title = keyboard.nextLine();
			
			System.out.print("ISBN to add: ");
			String ISBN = keyboard.nextLine();
			
			System.out.print("Year to add: ");
			String year = keyboard.nextLine();

			// a canned query to find book information (including author name) from title
			stmt = conn.prepareStatement(
					"Insert into books(Author_id, title, ISBN, published)\r\n"
					+ "	Values(?, ?, ?, ?);"
			);

			// substitute the title entered by the user for the placeholder in the query
			//find way to set 
			int author_id = 0;
			
			//get author_id
			
			//if author_id does not exist, create a new author
			
			stmt2 = conn.prepareStatement(
					"Insert into authors(lastname, firstname)\r\n" 
					+ " Values(?, ?)"
					);
			
			stmt2.setString(1, authorLastName);
			stmt2.setString(2,  authorFirstName);
			
			resultSet2 = stmt2.executeQuery();
			
			
			stmt.setInt(1, author_id);
			stmt.setString(2, title);
			stmt.setString(3, ISBN);
			stmt.setString(4, year);
			
			// execute the query
			resultSet = stmt.executeQuery();

			// get the precise schema of the tuples returned as the result of the query
			ResultSetMetaData resultSchema = stmt.getMetaData();

			// iterate through the returned tuples, printing each one
			// count # of rows returned
			int rowsReturned = 0;
			
			while (resultSet.next()) {
				for (int i = 1; i <= resultSchema.getColumnCount(); i++) {
					Object obj = resultSet.getObject(i);
					if (i > 1) {
						System.out.print(",");
					}
					System.out.print(obj.toString());
				}
				System.out.println();
				
				// count # of rows returned
				rowsReturned++;
			}
			
			// indicate if the query returned nothing
			if (rowsReturned == 0) {
				System.out.println("No rows returned that matched the query");
			}
		} finally {
			// close result set, statement, connection
			DBUtil.closeQuietly(resultSet);
			DBUtil.closeQuietly(stmt);
			DBUtil.closeQuietly(conn);
		}
	}
}
